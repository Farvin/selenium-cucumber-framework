package utils;

public class Links {
	
	public static String HOME_PAGE = "http://store.demoqa.com/";
	public static String IPHONE5_PRODUCT_PAGE = "http://store.demoqa.com/products-page/product-category/n/";

}
