package pages;

public class HomePage extends Page{
	
	public static String homePageTitle;
	
	public static void setHomePageTitle(String pageTitle) {
		HomePage.homePageTitle = pageTitle;
	}

	public static String getHomePageTitle() {
		return homePageTitle;
	}
	
	
	

}
